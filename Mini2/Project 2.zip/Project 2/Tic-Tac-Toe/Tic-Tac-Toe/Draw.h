#ifndef DRAW_H
#define DRAW_H

#include "freeglut\freeglut.h"
#include <vector>

class Draw
{
public:
	//std::vector<glVertex2f> coords;

	Draw()
	{
		//coords.assign(18);
	}

	~Draw();

	void addCoordinates()
	{
		//coords.push_back
	}
};

#endif // !DRAW_H
